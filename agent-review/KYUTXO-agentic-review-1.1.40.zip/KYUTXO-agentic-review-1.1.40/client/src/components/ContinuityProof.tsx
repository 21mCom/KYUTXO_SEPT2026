import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useToast } from "@/hooks/use-toast";
import { AddressLink } from "@/components/AddressLink";
import { TxidLink } from "@/components/TxidLink";
import {
  Loader2,
  CheckCircle2,
  Clock,
  ArrowRight,
  ChevronDown,
  ChevronRight,
  FileText,
  Download,
  RefreshCw,
  Shield,
  Calendar,
  Wallet,
  Coins,
  AlertCircle,
  AlertTriangle,
  GitBranch,
  MapPin,
  XCircle
} from "lucide-react";
import { 
  buildAllLineage,
  buildAllCustodySegments,
  getSegmentsForAddress,
  getLineageChainForAddress,
  getCustodyDuration,
  type CustodySegment,
  type UtxoLineage
} from "@/lib/lineageEngine";
import {
  countUtxoLineage,
  countCustodySegments,
  getCustodySegmentsBeforeIdFiltered,
  countCustodySegmentsFiltered,
  isCustodySegmentFilterActive,
  type CustodySegmentListFilter,
} from "@/lib/data/lineage-crud";
import { countTransactions } from "@/lib/data/transaction-crud";
import {
  buildSegmentProofPayload,
  downloadSegmentProofPdf,
  downloadAllSegmentProofsPdf,
  PdfExportCancelledError,
} from "@/lib/custody-proof-export";
import { computeOverallProgress, decideCancelAction } from "@/lib/buildProgress";
import { useSettings } from "@/hooks/use-settings";
import { useDebouncedValue } from "@/hooks/use-debounced-value";
import { DEBOUNCE_DELAY } from "@/config/debounce";
import { Input } from "@/components/ui/input";
import type { CustodyStatus } from "@/lib/db-types";
import { formatDistanceToNow } from "date-fns";
// CustodySegment.originDate is stored as Unix SECONDS (from
// blockchainTransactions.blockTime); the shared helpers convert to Date and
// render "Unknown" (never the 1970 epoch) for 0/missing block times.
import {
  unixSecondsToDate as originDateMs,
  formatUnixSeconds as formatOriginDate,
  msToUnixSeconds,
} from "@/lib/unix-seconds";

interface ContinuityProofProps {
  selectedAddress?: string;
  onAddressSelect?: (address: string) => void;
}

const LAST_BUILD_DURATION_KEY = 'kyutxo_last_build_duration_seconds';
const LAST_BUILD_META_KEY = 'kyutxo_last_build_meta';

// Page size for the unselected "All Custody Segments" list. Tens, not
// thousands — the vault can hold far more segments than can mount at once.
const ALL_SEGMENTS_PAGE_SIZE = 50;

// Status filter chips for the all-segments list. An empty selection means
// "no status filter" (all statuses) — the chips never represent "none".
const SEGMENT_STATUS_FILTER_OPTIONS: Array<{ value: CustodyStatus; label: string }> = [
  { value: 'active', label: 'Active' },
  { value: 'spent', label: 'Spent' },
  { value: 'split', label: 'Partial' },
  { value: 'consolidated', label: 'Merged' },
];

interface LastBuildMeta {
  durationSeconds: number;
  transactionCount: number;
  avgRate?: number;
  peakRate?: number;
}

function loadLastBuildMeta(): LastBuildMeta | null {
  try {
    const stored = localStorage.getItem(LAST_BUILD_META_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      if (parsed && typeof parsed.durationSeconds === 'number' && parsed.durationSeconds > 0) {
        return {
          durationSeconds: parsed.durationSeconds,
          transactionCount: typeof parsed.transactionCount === 'number' ? parsed.transactionCount : 0,
          avgRate: typeof parsed.avgRate === 'number' && parsed.avgRate > 0 ? parsed.avgRate : undefined,
          peakRate: typeof parsed.peakRate === 'number' && parsed.peakRate > 0 ? parsed.peakRate : undefined,
        };
      }
    }
    const oldStored = localStorage.getItem(LAST_BUILD_DURATION_KEY);
    if (oldStored !== null) {
      const parsed = parseInt(oldStored, 10);
      if (Number.isFinite(parsed) && parsed > 0) {
        localStorage.removeItem(LAST_BUILD_DURATION_KEY);
        return { durationSeconds: parsed, transactionCount: 0 };
      }
    }
  } catch {}
  return null;
}

export function ContinuityProof({ selectedAddress, onAddressSelect }: ContinuityProofProps) {
  const { toast } = useToast();
  const { cancelConfirmThreshold } = useSettings();
  
  const [isBuilding, setIsBuilding] = useState(false);
  const [buildProgress, setBuildProgress] = useState({ current: 0, total: 0, phase: '', step: 0, totalSteps: 2, unit: '' });
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);
  const abortControllerRef = useRef<AbortController | null>(null);
  const [segments, setSegments] = useState<CustodySegment[]>([]);
  const [segmentsHasMore, setSegmentsHasMore] = useState(false);
  const [segmentsLoading, setSegmentsLoading] = useState(false);
  const segmentsCursorRef = useRef<number | null>(null);
  const segmentsLoadTokenRef = useRef(0);
  // Mirror refs so the paged loader (stable callback, ref-driven) never reads
  // stale state: loaded-row count for the exact hasMore check, and an
  // in-flight flag so two appends can never overlap and duplicate rows.
  const segmentsLoadedRef = useRef(0);
  const segmentsLoadingRef = useRef(false);
  const segmentsTotalRef = useRef<number | null>(null);
  // Segment list filters (all-segments view only). Empty status selection =
  // no status filter. The address query is debounced so typing doesn't fire a
  // paged reload per keystroke.
  const [statusFilter, setStatusFilter] = useState<CustodyStatus[]>([]);
  const [addressFilterInput, setAddressFilterInput] = useState("");
  const [debouncedAddressFilter] = useDebouncedValue(addressFilterInput, DEBOUNCE_DELAY.MEDIUM);
  const [originFromInput, setOriginFromInput] = useState(""); // yyyy-mm-dd
  const [originToInput, setOriginToInput] = useState("");
  const [filteredSegmentCount, setFilteredSegmentCount] = useState<number | null>(null);
  // Combined "Export all as PDF" state. A dedicated AbortController (separate
  // from the lineage build's) cancels the export between segments.
  const [isExportingAll, setIsExportingAll] = useState(false);
  const [exportAllProgress, setExportAllProgress] = useState({ current: 0, total: 0 });
  const exportAllAbortRef = useRef<AbortController | null>(null);
  const [lineage, setLineage] = useState<UtxoLineage[]>([]);
  const [lineageTruncated, setLineageTruncated] = useState(false);
  const [expandedSegments, setExpandedSegments] = useState<Set<string>>(new Set());
  const [stats, setStats] = useState<{
    lineageCount: number;
    segmentCount: number;
    lastBuilt?: number;
  }>({ lineageCount: 0, segmentCount: 0 });
  const [currentTransactionCount, setCurrentTransactionCount] = useState(0);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const buildStartTimeRef = useRef<number>(0);
  const phaseStartTimeRef = useRef<number>(0);
  const phaseStartCountRef = useRef<number>(0);
  const rateTrackingRef = useRef({
    lastSampleTime: 0,
    lastSampleCount: 0,
    phasePeakRate: 0,
    lineageAvgRate: 0,
    lineagePeakRate: 0,
  });
  const ROLLING_WINDOW_SECONDS = 5;
  const rateSamplesRef = useRef<Array<{ time: number; count: number }>>([]);
  const [lastBuildMeta, setLastBuildMeta] = useState<LastBuildMeta | null>(loadLastBuildMeta);

  useEffect(() => {
    if (!isBuilding) {
      setElapsedSeconds(0);
      return;
    }
    const interval = setInterval(() => {
      setElapsedSeconds(Math.floor((Date.now() - buildStartTimeRef.current) / 1000));
    }, 1000);
    return () => clearInterval(interval);
  }, [isBuilding]);

  useEffect(() => {
    if (!isBuilding || buildProgress.current <= 0) return;
    const now = Date.now();
    const samples = rateSamplesRef.current;
    if (samples.length > 0 && samples[samples.length - 1].count === buildProgress.current) return;
    samples.push({ time: now, count: buildProgress.current });
    const cutoff = now - ROLLING_WINDOW_SECONDS * 2 * 1000;
    while (samples.length > 0 && samples[0].time < cutoff) {
      samples.shift();
    }
  }, [isBuilding, buildProgress]);

  const formatDuration = (totalSeconds: number): string => {
    if (totalSeconds < 1) return "0s";
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    const parts: string[] = [];
    if (hours > 0) parts.push(`${hours}h`);
    if (minutes > 0) parts.push(`${minutes}m`);
    if (seconds > 0 || parts.length === 0) parts.push(`${seconds}s`);
    return parts.join(' ');
  };

  const getProcessingRate = (): number | null => {
    const { current, total } = buildProgress;
    if (current <= 0 || total <= 0) return null;
    const samples = rateSamplesRef.current;
    if (samples.length < 1) return null;
    const now = Date.now();
    const cutoff = now - ROLLING_WINDOW_SECONDS * 2 * 1000;
    while (samples.length > 1 && samples[0].time < cutoff) {
      samples.shift();
    }
    const windowStart = now - ROLLING_WINDOW_SECONDS * 1000;
    let startIdx = 0;
    for (let i = samples.length - 1; i >= 0; i--) {
      if (samples[i].time <= windowStart) {
        startIdx = i;
        break;
      }
    }
    const startSample = samples[startIdx];
    const elapsed = (now - startSample.time) / 1000;
    if (elapsed < 1.5) return null;
    const processed = current - startSample.count;
    if (processed <= 0) return null;
    return processed / elapsed;
  };

  const formatRate = (rate: number): string => {
    if (rate >= 1000) return `~${(rate / 1000).toFixed(1)}k`;
    if (rate >= 100) return `~${Math.round(rate)}`;
    if (rate >= 10) return `~${rate.toFixed(1)}`;
    return `~${rate.toFixed(2)}`;
  };

  const getEstimatedRemaining = (): string | null => {
    const rate = getProcessingRate();
    const { current, total } = buildProgress;
    if (!rate || current >= total) return null;
    const remaining = (total - current) / rate;
    if (remaining < 1) return null;
    return formatDuration(Math.ceil(remaining));
  };

  const samplePeakRate = (current: number) => {
    const tracking = rateTrackingRef.current;
    const now = Date.now();
    const elapsed = (now - tracking.lastSampleTime) / 1000;
    if (elapsed >= 2 && tracking.lastSampleTime > 0) {
      const delta = current - tracking.lastSampleCount;
      if (delta > 0) {
        const rate = delta / elapsed;
        if (rate > tracking.phasePeakRate) {
          tracking.phasePeakRate = rate;
        }
      }
      tracking.lastSampleTime = now;
      tracking.lastSampleCount = current;
    } else if (tracking.lastSampleTime === 0) {
      tracking.lastSampleTime = now;
      tracking.lastSampleCount = current;
    }
  };

  const resetPhasePeakTracking = () => {
    const tracking = rateTrackingRef.current;
    tracking.lastSampleTime = 0;
    tracking.lastSampleCount = 0;
    tracking.phasePeakRate = 0;
  };

  // Load stats on mount
  const loadStats = useCallback(async () => {
    const lineageCount = await countUtxoLineage();
    const segmentCount = await countCustodySegments();
    const txCount = await countTransactions();
    setStats({ lineageCount, segmentCount });
    setCurrentTransactionCount(txCount);
  }, []);
  
  useEffect(() => {
    loadStats();
  }, [loadStats]);
  
  // Applied segment filters. Date inputs are yyyy-mm-dd; originDate is stored
  // as Unix SECONDS, so convert with UTC day bounds (start/end of day).
  const segmentFilters = useMemo<CustodySegmentListFilter>(() => ({
    statuses: statusFilter,
    addressQuery: debouncedAddressFilter,
    originDateFrom: originFromInput
      ? msToUnixSeconds(Date.parse(`${originFromInput}T00:00:00Z`))
      : undefined,
    originDateTo: originToInput
      ? msToUnixSeconds(Date.parse(`${originToInput}T23:59:59.999Z`))
      : undefined,
  }), [statusFilter, debouncedAddressFilter, originFromInput, originToInput]);
  const segmentFiltersActive = isCustodySegmentFilterActive(segmentFilters);

  // Paged loader for the unselected "All Custody Segments" view. Keyset
  // pagination by descending id (newest built first) so the whole table is
  // never materialised or mounted. A load token guards against a stale page
  // landing after the selection or the filters changed underneath an
  // in-flight read — any filter change alters this callback's identity, which
  // re-runs the reset effect below and bumps the token, so pages from a
  // previous filter can never interleave with the new one.
  const loadAllSegmentsPage = useCallback(async (reset: boolean) => {
    if (reset) {
      segmentsLoadTokenRef.current += 1;
    } else if (segmentsLoadingRef.current) {
      // Never overlap appends: a second in-flight page would read the same
      // cursor and append duplicate rows.
      return;
    }
    const token = segmentsLoadTokenRef.current;
    segmentsLoadingRef.current = true;
    setSegmentsLoading(true);
    if (reset) {
      // Never show a previous filter's total alongside the new filter.
      setFilteredSegmentCount(null);
      segmentsTotalRef.current = null;
    }
    try {
      const beforeId = reset
        ? Number.MAX_SAFE_INTEGER
        : (segmentsCursorRef.current ?? Number.MAX_SAFE_INTEGER);
      const page = await getCustodySegmentsBeforeIdFiltered(beforeId, ALL_SEGMENTS_PAGE_SIZE, segmentFilters);
      if (token !== segmentsLoadTokenRef.current) return;
      const lastId = page.length > 0 ? page[page.length - 1].id : undefined;
      segmentsCursorRef.current = typeof lastId === 'number' ? lastId : null;
      const loadedSoFar = (reset ? 0 : segmentsLoadedRef.current) + page.length;
      segmentsLoadedRef.current = loadedSoFar;
      setSegments(prev => (reset ? page : [...prev, ...page]));
      // Provisional: let the button render as soon as a full page lands.
      setSegmentsHasMore(page.length === ALL_SEGMENTS_PAGE_SIZE);
      // Deferred-count discipline: the count query only starts once the page
      // rows are queued for render, and it runs once per reset — later pages
      // of the same filter reuse the reset's total. The setter is
      // token-guarded so a superseded load can never overwrite a newer
      // filter's total.
      let total = segmentsTotalRef.current;
      if (total === null) {
        total = await countCustodySegmentsFiltered(segmentFilters);
        if (token !== segmentsLoadTokenRef.current) return;
        segmentsTotalRef.current = total;
        setFilteredSegmentCount(total);
      }
      // Exact hasMore (replaces the full-page heuristic once the total is
      // known), so the button can't linger on an exact-multiple boundary.
      setSegmentsHasMore(loadedSoFar < total);
    } catch (error) {
      // Surface load failures — a silently swallowed error leaves Load more
      // looking dead with no explanation.
      if (token === segmentsLoadTokenRef.current) {
        toast({
          variant: "destructive",
          title: "Couldn't load segments",
          description: error instanceof Error ? error.message : "An error occurred while loading custody segments.",
        });
      }
    } finally {
      if (token === segmentsLoadTokenRef.current) {
        segmentsLoadingRef.current = false;
        setSegmentsLoading(false);
      }
    }
  }, [segmentFilters, toast]);

  // Load data for the selected address, or the paged all-segments list when
  // nothing is selected.
  useEffect(() => {
    if (selectedAddress) {
      // Invalidate any in-flight all-segments page so it can't overwrite the
      // per-address view.
      segmentsLoadTokenRef.current += 1;
      segmentsLoadingRef.current = false;
      setSegmentsHasMore(false);
      setSegmentsLoading(false);
      loadAddressData(selectedAddress);
    } else {
      void loadAllSegmentsPage(true);
    }
  }, [selectedAddress, loadAllSegmentsPage]);

  const toggleSegmentStatusFilter = useCallback((status: CustodyStatus) => {
    setStatusFilter(prev => {
      // Empty selection means "all statuses". Clicking a chip while all are
      // on solos that status; clicking the last active chip returns to all.
      if (prev.length === 0) return [status];
      if (prev.includes(status)) return prev.filter(s => s !== status);
      const next = [...prev, status];
      return next.length === SEGMENT_STATUS_FILTER_OPTIONS.length ? [] : next;
    });
  }, []);

  const clearSegmentFilters = useCallback(() => {
    setStatusFilter([]);
    setAddressFilterInput("");
    setOriginFromInput("");
    setOriginToInput("");
  }, []);

  const loadAddressData = async (address: string) => {
    const addressSegments = await getSegmentsForAddress(address);
    setSegments(addressSegments);

    const result = await getLineageChainForAddress(address, 20, 2000);
    setLineage(result.chain);
    setLineageTruncated(result.truncated);
  };
  
  const getOverallProgress = useCallback((): number => {
    return computeOverallProgress(buildProgress);
  }, [buildProgress]);

  const handleCancelBuild = useCallback(() => {
    const action = decideCancelAction(!!abortControllerRef.current, getOverallProgress(), cancelConfirmThreshold);
    if (action === 'show_confirm') {
      setShowCancelConfirm(true);
    } else if (action === 'abort') {
      abortControllerRef.current!.abort();
    }
  }, [getOverallProgress, cancelConfirmThreshold]);

  const handleConfirmCancel = useCallback(() => {
    setShowCancelConfirm(false);
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
  }, []);

  const handleBuildLineage = async () => {
    const controller = new AbortController();
    abortControllerRef.current = controller;
    const now = Date.now();
    buildStartTimeRef.current = now;
    phaseStartTimeRef.current = now;
    phaseStartCountRef.current = 0;
    resetPhasePeakTracking();
    rateTrackingRef.current.lineageAvgRate = 0;
    rateTrackingRef.current.lineagePeakRate = 0;
    rateSamplesRef.current = [];
    setIsBuilding(true);
    setBuildProgress({ current: 0, total: 0, phase: 'Scanning transactions...', step: 1, totalSteps: 2, unit: 'transactions' });
    
    try {
      const lineageResult = await buildAllLineage((current, total) => {
        samplePeakRate(current);
        setBuildProgress({ current, total, phase: 'Building UTXO lineage', step: 1, totalSteps: 2, unit: 'transactions' });
      }, controller.signal);
      
      const lineageElapsed = (Date.now() - phaseStartTimeRef.current) / 1000;
      const lineageAvg = lineageElapsed > 0 ? lineageResult.processed / lineageElapsed : 0;
      const lineagePeak = rateTrackingRef.current.phasePeakRate;
      rateTrackingRef.current.lineageAvgRate = lineageAvg;
      rateTrackingRef.current.lineagePeakRate = lineagePeak;

      if (controller.signal.aborted) {
        toast({
          title: "Build Cancelled",
          description: `Cancelled during lineage phase. ${lineageResult.processed} transactions processed, ${lineageResult.created} links created before cancellation.`,
        });
        return;
      }

      toast({
        title: "Lineage Built",
        description: `Processed ${lineageResult.processed} transactions, created ${lineageResult.created} lineage links.`,
      });
      
      resetPhasePeakTracking();
      phaseStartTimeRef.current = Date.now();
      phaseStartCountRef.current = 0;
      rateSamplesRef.current = [];
      setBuildProgress({ current: 0, total: 0, phase: 'Scanning origin UTXOs...', step: 2, totalSteps: 2, unit: 'origins' });
      
      const segmentResult = await buildAllCustodySegments((current, total) => {
        samplePeakRate(current);
        setBuildProgress({ current, total, phase: 'Compiling custody segments', step: 2, totalSteps: 2, unit: 'origins' });
      }, controller.signal);
      
      if (controller.signal.aborted) {
        toast({
          title: "Build Cancelled",
          description: `Cancelled during custody phase. ${segmentResult.processed} origins processed, ${segmentResult.created} segments created before cancellation.`,
        });
        return;
      }

      toast({
        title: "Custody Segments Compiled",
        description: `Created ${segmentResult.created} custody segments from ${segmentResult.processed} origins.`,
      });

      const totalSeconds = Math.round((Date.now() - buildStartTimeRef.current) / 1000);
      const avgRate = rateTrackingRef.current.lineageAvgRate;
      const peakRate = rateTrackingRef.current.lineagePeakRate;

      if (totalSeconds > 0) {
        const txCount = await countTransactions();
        const meta: LastBuildMeta = {
          durationSeconds: totalSeconds,
          transactionCount: txCount,
          avgRate: avgRate > 0 ? Math.round(avgRate * 10) / 10 : undefined,
          peakRate: peakRate > 0 ? Math.round(peakRate * 10) / 10 : undefined,
        };
        try {
          localStorage.setItem(LAST_BUILD_META_KEY, JSON.stringify(meta));
          localStorage.removeItem(LAST_BUILD_DURATION_KEY);
        } catch {}
        setLastBuildMeta(meta);
      }

      if (avgRate > 0 || peakRate > 0) {
        const rateParts: string[] = [];
        if (avgRate > 0) rateParts.push(`avg: ${formatRate(avgRate)} txns/sec`);
        if (peakRate > 0) rateParts.push(`peak: ${formatRate(peakRate)} txns/sec`);
        toast({
          title: "Build Complete",
          description: `Finished in ${formatDuration(totalSeconds)}. ${rateParts.join(', ')}.`,
        });
      }
      
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Build Failed",
        description: error instanceof Error ? error.message : "An error occurred",
      });
    } finally {
      abortControllerRef.current = null;
      setIsBuilding(false);
      setBuildProgress({ current: 0, total: 0, phase: '', step: 0, totalSteps: 2, unit: '' });
      await loadStats();
      if (selectedAddress) {
        await loadAddressData(selectedAddress);
      } else {
        // Refresh the paged all-segments list so newly built segments appear
        // even when no address is selected.
        await loadAllSegmentsPage(true);
      }
    }
  };
  
  const toggleSegment = (segmentId: string) => {
    const newSet = new Set(expandedSegments);
    if (newSet.has(segmentId)) {
      newSet.delete(segmentId);
    } else {
      newSet.add(segmentId);
    }
    setExpandedSegments(newSet);
  };
  
  const formatBtc = (sats: number) => {
    return (sats / 100_000_000).toFixed(8);
  };
  
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge variant="default" className="bg-green-500/10 text-green-700 border-green-500/20">Active</Badge>;
      case 'spent':
        return <Badge variant="secondary" className="bg-red-500/10 text-red-700 border-red-500/20">Spent</Badge>;
      case 'split':
        return <Badge variant="outline" className="bg-yellow-500/10 text-yellow-700 border-yellow-500/20">Partial</Badge>;
      case 'consolidated':
        return <Badge variant="outline" className="bg-blue-500/10 text-blue-700 border-blue-500/20">Merged</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  const getConfidenceBadge = (confidence: string) => {
    switch (confidence) {
      case 'verified':
        return <Badge variant="default" className="bg-green-500/10 text-green-700 border-green-500/20">Verified</Badge>;
      case 'high':
        return <Badge variant="secondary" className="bg-blue-500/10 text-blue-700 border-blue-500/20">High</Badge>;
      case 'medium':
        return <Badge variant="outline" className="bg-yellow-500/10 text-yellow-700 border-yellow-500/20">Medium</Badge>;
      case 'low':
        return <Badge variant="outline" className="bg-orange-500/10 text-orange-700 border-orange-500/20">Low</Badge>;
      default:
        return <Badge variant="outline" className="text-muted-foreground">Unknown</Badge>;
    }
  };
  
  const handleExportSegment = (segment: CustodySegment) => {
    const exportData = buildSegmentProofPayload(segment);

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `custody-proof-${segment.segmentId}.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "Exported",
      description: "Custody proof exported to JSON file.",
    });
  };

  const handleExportSegmentPdf = async (segment: CustodySegment) => {
    try {
      await downloadSegmentProofPdf(buildSegmentProofPayload(segment));
      toast({
        title: "Exported",
        description: "Custody proof exported to PDF file.",
      });
    } catch (err) {
      console.error("[ContinuityProof] PDF export failed:", err);
      toast({
        variant: "destructive",
        title: "PDF Export Failed",
        description: err instanceof Error ? err.message : "An unexpected error occurred during PDF generation.",
      });
    }
  };
  
  // Export every custody segment matching the active filters into one
  // combined PDF. Pages through the DB with the same keyset fetcher + filter
  // as the list, so what's exported is exactly what the list would show.
  const handleExportAllSegmentsPdf = async () => {
    if (isExportingAll) return;
    const controller = new AbortController();
    exportAllAbortRef.current = controller;
    setIsExportingAll(true);
    setExportAllProgress({ current: 0, total: 0 });
    try {
      const total = segmentsTotalRef.current ?? await countCustodySegmentsFiltered(segmentFilters);
      if (total === 0) {
        toast({
          title: "Nothing to Export",
          description: segmentFiltersActive
            ? "No custody segments match the current filters."
            : "No custody segments have been built yet.",
        });
        return;
      }
      setExportAllProgress({ current: 0, total });
      const exported = await downloadAllSegmentProofsPdf({
        fetchPage: (beforeId, limit) =>
          getCustodySegmentsBeforeIdFiltered(beforeId, limit, segmentFilters),
        totalCount: total,
        signal: controller.signal,
        onProgress: (current, totalCount) =>
          setExportAllProgress({ current, total: totalCount }),
      });
      toast({
        title: "Exported",
        description: `${exported} custody segment${exported === 1 ? "" : "s"} exported to a combined PDF.`,
      });
    } catch (err) {
      if (err instanceof PdfExportCancelledError) {
        toast({
          title: "Export Cancelled",
          description: "The combined PDF export was cancelled. No file was saved.",
        });
      } else {
        console.error("[ContinuityProof] Combined PDF export failed:", err);
        toast({
          variant: "destructive",
          title: "PDF Export Failed",
          description: err instanceof Error ? err.message : "An unexpected error occurred during PDF generation.",
        });
      }
    } finally {
      exportAllAbortRef.current = null;
      setIsExportingAll(false);
      setExportAllProgress({ current: 0, total: 0 });
    }
  };

  const handleCancelExportAll = () => {
    exportAllAbortRef.current?.abort();
  };

  const renderSegmentCard = (segment: CustodySegment) => {
    const isExpanded = expandedSegments.has(segment.segmentId);
    const duration = getCustodyDuration([segment]);
    // Segments restored from older backups can be sparse: evidenceTxids is
    // typed required but may be absent in stored rows. One such row used to
    // crash the whole list render (no error boundary), which surfaced as
    // "Load more does nothing" the moment a paged append pulled a sparse row
    // onto the page. Never let a sparse row take the list down.
    const evidenceTxids = Array.isArray(segment.evidenceTxids) ? segment.evidenceTxids : [];
    
    return (
      <Collapsible
        key={segment.segmentId}
        open={isExpanded}
        onOpenChange={() => toggleSegment(segment.segmentId)}
      >
        <Card className="border">
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer hover-elevate pb-3">
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-center gap-2">
                  {isExpanded ? (
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <ChevronRight className="h-4 w-4 text-muted-foreground" />
                  )}
                  <div>
                    <CardTitle className="text-base flex items-center gap-2 flex-wrap">
                      <Coins className="h-4 w-4 text-primary" />
                      {formatBtc(segment.originAmount)} BTC
                      {getStatusBadge(segment.status)}
                      {segment.lineageTruncated && (
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Badge variant="outline" className="bg-yellow-500/10 text-yellow-700 dark:text-yellow-400 border-yellow-500/20" data-testid={`badge-truncated-${segment.segmentId}`}>
                              <AlertTriangle className="h-3 w-3 mr-1" />
                              Partial
                            </Badge>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Custody trail may be incomplete — lineage data was truncated due to traversal limits.</p>
                          </TooltipContent>
                        </Tooltip>
                      )}
                    </CardTitle>
                    <CardDescription className="mt-1">
                      {segment.narrative || `Custody from ${formatOriginDate(segment.originDate, 'MMM d, yyyy')}`}
                    </CardDescription>
                  </div>
                </div>
                <div className="text-right text-sm text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    {originDateMs(segment.originDate) ? formatDistanceToNow(originDateMs(segment.originDate)!, { addSuffix: true }) : "Unknown"}
                  </div>
                  {duration.totalDays > 0 && (
                    <div className="text-xs">{duration.totalDays} days custody</div>
                  )}
                </div>
              </div>
            </CardHeader>
          </CollapsibleTrigger>
          
          <CollapsibleContent>
            <CardContent className="pt-0 space-y-4">
              <Separator />
              
              {/* Origin Details */}
              <div className="space-y-2">
                <h4 className="text-sm font-medium flex items-center gap-2">
                  <MapPin className="h-3 w-3 text-green-500" />
                  Origin
                </h4>
                <div className="grid gap-2 text-sm pl-5">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Address:</span>
                    <AddressLink address={segment.originAddress} />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Transaction:</span>
                    <TxidLink txid={segment.originTxid} />
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Date:</span>
                    <span>{formatOriginDate(segment.originDate, 'MMM d, yyyy HH:mm')}</span>
                  </div>
                  {segment.acquisitionMethod && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Acquisition:</span>
                      <Badge variant="outline">{segment.acquisitionMethod}</Badge>
                    </div>
                  )}
                  {segment.costBasisUsd && (
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Cost Basis:</span>
                      <span>${segment.costBasisUsd.toLocaleString()}</span>
                    </div>
                  )}
                </div>
              </div>
              
              {/* Current State (if still held) */}
              {segment.currentAddress && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium flex items-center gap-2">
                    <Wallet className="h-3 w-3 text-blue-500" />
                    Current Location
                  </h4>
                  <div className="grid gap-2 text-sm pl-5">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Address:</span>
                      <AddressLink address={segment.currentAddress} />
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Amount:</span>
                      <span className="font-mono">{formatBtc(segment.currentAmount)} BTC</span>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Transfer History */}
              {segment.hopCount > 0 && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium flex items-center gap-2">
                    <GitBranch className="h-3 w-3 text-purple-500" />
                    Transfer History ({segment.hopCount} hop{segment.hopCount !== 1 ? 's' : ''})
                  </h4>
                  <div className="pl-5">
                    <ScrollArea className="max-h-32">
                      <div className="space-y-1">
                        {evidenceTxids.map((txid, idx) => (
                          <div key={txid} className="flex items-center gap-2 text-xs">
                            <span className="text-muted-foreground">{idx + 1}.</span>
                            <TxidLink txid={txid} />
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  </div>
                </div>
              )}
              
              {/* Metadata */}
              {(segment.owner || segment.walletName || segment.seedName) && (
                <div className="space-y-2">
                  <h4 className="text-sm font-medium flex items-center gap-2">
                    <Shield className="h-3 w-3 text-primary" />
                    Metadata
                  </h4>
                  <div className="flex flex-wrap gap-2 pl-5">
                    {segment.owner && (
                      <Badge variant="outline">{segment.owner}</Badge>
                    )}
                    {segment.walletName && (
                      <Badge variant="secondary">{segment.walletName}</Badge>
                    )}
                    {segment.seedName && (
                      <Badge variant="outline" className="text-muted-foreground">{segment.seedName}</Badge>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
            
            <CardFooter className="pt-0 gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleExportSegment(segment)}
                data-testid={`button-export-segment-${segment.segmentId}`}
              >
                <Download className="h-3 w-3 mr-1" />
                Export Proof
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => handleExportSegmentPdf(segment)}
                data-testid={`button-export-segment-pdf-${segment.segmentId}`}
              >
                <FileText className="h-3 w-3 mr-1" />
                Export PDF
              </Button>
            </CardFooter>
          </CollapsibleContent>
        </Card>
      </Collapsible>
    );
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Continuity Proof
        </CardTitle>
        <CardDescription>
          Build and export ownership proofs showing the chain of custody for your Bitcoin.
          Demonstrates long-term holding through address changes and partial spends.
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {/* Stats */}
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="text-center p-3 bg-muted/50 rounded-lg">
            <div className="text-2xl font-bold" data-testid="text-lineage-count">
              {stats.lineageCount}
            </div>
            <div className="text-xs text-muted-foreground">Lineage Links</div>
          </div>
          <div className="text-center p-3 bg-muted/50 rounded-lg">
            <div className="text-2xl font-bold" data-testid="text-segment-count">
              {stats.segmentCount}
            </div>
            <div className="text-xs text-muted-foreground">Custody Segments</div>
          </div>
          <div className="text-center p-3 bg-muted/50 rounded-lg">
            <Button
              onClick={handleBuildLineage}
              disabled={isBuilding}
              className="w-full"
              data-testid="button-build-lineage"
            >
              {isBuilding ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Building...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Build Lineage
                </>
              )}
            </Button>
            {!isBuilding && lastBuildMeta !== null && (
              <div className="text-xs text-muted-foreground mt-1.5" data-testid="text-last-build-duration">
                <Clock className="h-3 w-3 inline-block mr-1 align-text-bottom" />
                {lastBuildMeta.transactionCount > 0 ? (
                  currentTransactionCount > lastBuildMeta.transactionCount ? (
                    <span data-testid="text-build-size-warning">
                      Last build: {formatDuration(lastBuildMeta.durationSeconds)} with {lastBuildMeta.transactionCount.toLocaleString()} transactions {'\u2014'} now {currentTransactionCount.toLocaleString()} transactions, estimated ~{formatDuration(Math.round(lastBuildMeta.durationSeconds * (currentTransactionCount / lastBuildMeta.transactionCount)))}
                    </span>
                  ) : (
                    <span>
                      Last build: {formatDuration(lastBuildMeta.durationSeconds)} with {lastBuildMeta.transactionCount.toLocaleString()} transactions
                    </span>
                  )
                ) : (
                  <span>Last build: {formatDuration(lastBuildMeta.durationSeconds)}</span>
                )}
                {(lastBuildMeta.avgRate || lastBuildMeta.peakRate) && (
                  <span className="block mt-0.5" data-testid="text-last-build-rates">
                    {lastBuildMeta.avgRate ? `avg: ${formatRate(lastBuildMeta.avgRate)} txns/sec` : ''}
                    {lastBuildMeta.avgRate && lastBuildMeta.peakRate ? ' · ' : ''}
                    {lastBuildMeta.peakRate ? `peak: ${formatRate(lastBuildMeta.peakRate)} txns/sec` : ''}
                  </span>
                )}
              </div>
            )}
          </div>
        </div>
        
        {isBuilding && (
          <div className="space-y-2 p-3 bg-muted/30 rounded-lg" data-testid="lineage-build-progress">
            <div className="flex items-center justify-between gap-2 text-sm">
              <span className="font-medium flex items-center gap-2">
                <Loader2 className="h-3 w-3 animate-spin" />
                Step {buildProgress.step} of {buildProgress.totalSteps}: {buildProgress.phase}
              </span>
              <div className="flex items-center gap-2">
                {buildProgress.total > 0 && (
                  <span className="text-muted-foreground tabular-nums" data-testid="text-build-counter">
                    {buildProgress.current.toLocaleString()} of {buildProgress.total.toLocaleString()} {buildProgress.unit}
                  </span>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleCancelBuild}
                  data-testid="button-cancel-build"
                >
                  <XCircle className="h-3 w-3 mr-1" />
                  Cancel
                </Button>
              </div>
            </div>
            <Progress
              value={buildProgress.total > 0 ? (buildProgress.current / buildProgress.total) * 100 : undefined}
              data-testid="progress-lineage-build"
            />
            <div className="flex items-center justify-between text-xs text-muted-foreground">
              <div className="flex items-center gap-3">
                <span className="flex items-center gap-1 tabular-nums" data-testid="text-build-elapsed">
                  <Clock className="h-3 w-3" />
                  {formatDuration(elapsedSeconds)} elapsed
                </span>
                {(() => {
                  const rate = getProcessingRate();
                  return rate ? (
                    <span className="tabular-nums" data-testid="text-build-rate">
                      {formatRate(rate)} {buildProgress.unit}/sec
                    </span>
                  ) : null;
                })()}
              </div>
              <div className="flex items-center gap-3">
                {(() => {
                  const eta = getEstimatedRemaining();
                  return eta ? (
                    <span className="tabular-nums" data-testid="text-build-eta">
                      ~{eta} remaining
                    </span>
                  ) : null;
                })()}
                {buildProgress.total > 0 && (
                  <span data-testid="text-build-percent">
                    {Math.round((buildProgress.current / buildProgress.total) * 100)}% complete
                  </span>
                )}
              </div>
            </div>
          </div>
        )}
        
        <Separator />
        
        {/* Segments for selected address or all segments */}
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-sm font-medium">
              {selectedAddress ? (
                <>Custody History for Selected Address</>
              ) : (
                <>All Custody Segments</>
              )}
            </h3>
            {!selectedAddress && (
              isExportingAll ? (
                <div className="flex items-center gap-2 text-xs text-muted-foreground" data-testid="export-all-progress">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  <span className="tabular-nums" data-testid="text-export-all-counter">
                    {exportAllProgress.total > 0
                      ? `Exporting ${exportAllProgress.current.toLocaleString()} of ${exportAllProgress.total.toLocaleString()}…`
                      : "Preparing export…"}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 px-2 text-xs"
                    onClick={handleCancelExportAll}
                    data-testid="button-cancel-export-all"
                  >
                    <XCircle className="h-3 w-3 mr-1" />
                    Cancel
                  </Button>
                </div>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => void handleExportAllSegmentsPdf()}
                  disabled={isBuilding || (filteredSegmentCount ?? stats.segmentCount) === 0}
                  data-testid="button-export-all-segments-pdf"
                >
                  <FileText className="h-3 w-3 mr-1" />
                  Export All as PDF{segmentFiltersActive ? " (filtered)" : ""}
                </Button>
              )
            )}
          </div>

          {/* Server-side filters for the paged all-segments list. The
              per-address view takes precedence: filters are hidden while an
              address is selected and do not affect it. */}
          {!selectedAddress && (
            <div className="flex flex-wrap items-center gap-2" data-testid="segment-filters">
              <div className="flex flex-wrap items-center gap-1" role="group" aria-label="Filter by custody status">
                {SEGMENT_STATUS_FILTER_OPTIONS.map((option) => {
                  const active = statusFilter.length === 0 || statusFilter.includes(option.value);
                  return (
                    <Button
                      key={option.value}
                      variant={active ? "secondary" : "outline"}
                      size="sm"
                      className="h-7 px-2 text-xs"
                      aria-pressed={active}
                      onClick={() => toggleSegmentStatusFilter(option.value)}
                      data-testid={`filter-status-${option.value}`}
                    >
                      {option.label}
                    </Button>
                  );
                })}
              </div>
              <Input
                value={addressFilterInput}
                onChange={(e) => setAddressFilterInput(e.target.value)}
                placeholder="Filter by address…"
                className="h-7 w-52 text-xs"
                data-testid="input-filter-address"
              />
              <Input
                type="date"
                value={originFromInput}
                onChange={(e) => setOriginFromInput(e.target.value)}
                className="h-7 w-36 text-xs"
                aria-label="Origin date from"
                data-testid="input-filter-origin-from"
              />
              <span className="text-xs text-muted-foreground">to</span>
              <Input
                type="date"
                value={originToInput}
                onChange={(e) => setOriginToInput(e.target.value)}
                className="h-7 w-36 text-xs"
                aria-label="Origin date to"
                data-testid="input-filter-origin-to"
              />
              {segmentFiltersActive && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 px-2 text-xs"
                  onClick={clearSegmentFilters}
                  data-testid="button-clear-segment-filters"
                >
                  Clear filters
                </Button>
              )}
            </div>
          )}

          {segments.length === 0 ? (
            !selectedAddress && segmentsLoading ? (
              <div className="text-sm text-muted-foreground" data-testid="text-segments-loading">
                Loading segments…
              </div>
            ) : (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>No Segments Found</AlertTitle>
              <AlertDescription>
                {selectedAddress ? (
                  <>No custody segments found for this address. The address may not have any tracked transactions.</>
                ) : segmentFiltersActive ? (
                  <>No custody segments match the current filters. Adjust or clear the filters to see more.</>
                ) : stats.segmentCount === 0 && stats.lineageCount === 0 ? (
                  <>Click "Build Lineage" to analyze your transaction history and create custody segments.</>
                ) : stats.segmentCount === 0 ? (
                  <>No custody segments built yet. This may indicate no owned addresses received funds in synced transactions.</>
                ) : (
                  <>No custody segments to display.</>
                )}
              </AlertDescription>
            </Alert>
            )
          ) : (
            <>
              <ScrollArea className="max-h-[500px]">
                <div className="space-y-3 pr-4">
                  {segments.map(segment => renderSegmentCard(segment))}
                </div>
              </ScrollArea>
              {!selectedAddress && (
                <div className="flex items-center justify-between gap-2 text-xs text-muted-foreground">
                  <span data-testid="text-segments-showing">
                    Showing {segments.length.toLocaleString()} of {(filteredSegmentCount ?? stats.segmentCount).toLocaleString()} segments{segmentFiltersActive ? " (filtered)" : ""}
                  </span>
                  {segmentsHasMore && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => void loadAllSegmentsPage(false)}
                      disabled={segmentsLoading}
                      data-testid="button-load-more-segments"
                    >
                      {segmentsLoading && <Loader2 className="h-3 w-3 mr-1 animate-spin" />}
                      Load more
                    </Button>
                  )}
                </div>
              )}
            </>
          )}
        </div>
        
        {/* Lineage chain visualization (if selected address) */}
        {selectedAddress && lineage.length > 0 && (
          <>
            <Separator />
            <div className="space-y-3">
              <h3 className="text-sm font-medium">Lineage Chain ({lineage.length} links)</h3>
              {lineageTruncated && (
                <Alert variant="default" data-testid="alert-lineage-truncated">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertTitle>Results Truncated</AlertTitle>
                  <AlertDescription>
                    Showing first {lineage.length.toLocaleString()} of many results. The full lineage chain exceeds traversal limits.
                  </AlertDescription>
                </Alert>
              )}
              <ScrollArea className="max-h-48">
                <div className="space-y-2">
                  {lineage.map((link, idx) => (
                    <div 
                      key={`${link.createdTxid}-${link.createdVout}-${idx}`}
                      className="flex items-center gap-2 text-sm p-2 bg-muted/30 rounded"
                    >
                      <span className="text-muted-foreground w-6">{idx + 1}.</span>
                      <AddressLink address={link.spentAddress} truncate={true} />
                      <ArrowRight className="h-3 w-3 text-muted-foreground" />
                      <AddressLink address={link.createdAddress} truncate={true} />
                      <span className="text-muted-foreground ml-auto">{formatBtc(link.createdAmount)} BTC</span>
                      {getConfidenceBadge(link.confidence)}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </>
        )}
      </CardContent>

      <AlertDialog open={showCancelConfirm} onOpenChange={setShowCancelConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Cancel Build?</AlertDialogTitle>
            <AlertDialogDescription>
              This build is {Math.round(getOverallProgress())}% complete.
              {buildProgress.step >= 2
                ? " Lineage data from step 1 is already saved, and custody segments created so far will be kept. However, the remaining items won't be processed."
                : " Data processed so far will be kept, but the remaining items won't be processed."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-build-dismiss">Continue Building</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmCancel}
              className="bg-destructive text-destructive-foreground"
              data-testid="button-cancel-build-confirm"
            >
              Cancel Build
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
